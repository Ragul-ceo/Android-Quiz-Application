// QuizActivity.java
package pyquiz.example.pyquiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class QuizActivity extends Activity {

    TextView questionTextView;
    RadioGroup optionsGroup;
    Button nextButton;
    
    String[] questions = {"Question 1?", "Question 2?", "Question 3?", "Question 4?", "Question 5?", 
                          "Question 6?", "Question 7?", "Question 8?", "Question 9?", "Question 10?"};
    String[][] options = {{"A", "B", "C", "D"}, {"A", "B", "C", "D"}, {"A", "B", "C", "D"},
                          {"A", "B", "C", "D"}, {"A", "B", "C", "D"}, {"A", "B", "C", "D"},
                          {"A", "B", "C", "D"}, {"A", "B", "C", "D"}, {"A", "B", "C", "D"},
                          {"A", "B", "C", "D"}};
    int[] correctAnswers = {0, 1, 2, 3, 0, 1, 2, 3, 0, 1}; // Example correct answers
    int currentQuestionIndex = 0;
    int score = 0;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        username = getIntent().getStringExtra("username");

        questionTextView = (TextView) findViewById(R.id.questionTextView);
        optionsGroup = (RadioGroup) findViewById(R.id.optionsGroup);
        nextButton = (Button) findViewById(R.id.nextButton);

        loadQuestion();

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedOption = optionsGroup.indexOfChild(findViewById(optionsGroup.getCheckedRadioButtonId()));
                if (selectedOption == correctAnswers[currentQuestionIndex]) {
                    score++;
                }

                currentQuestionIndex++;

                if (currentQuestionIndex < questions.length) {
                    loadQuestion();
                } else {
                    // Quiz finished, store result and show scorecard
                    DBHelper dbHelper = new DBHelper(QuizActivity.this);
                    dbHelper.addUser(username, score);

                    Intent intent = new Intent(QuizActivity.this, ScoreCardActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                }
            }
        });
    }

    // Load the current question and options
    private void loadQuestion() {
        questionTextView.setText(questions[currentQuestionIndex]);
        optionsGroup.clearCheck();
        for (int i = 0; i < options[currentQuestionIndex].length; i++) {
            ((RadioButton) optionsGroup.getChildAt(i)).setText(options[currentQuestionIndex][i]);
        }
    }
}

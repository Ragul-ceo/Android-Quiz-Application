// ScoreCardActivity.java
package pyquiz.example.pyquiz;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ScoreCardActivity extends Activity {

    TextView scoreTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scorecard);

        scoreTextView = (TextView) findViewById(R.id.scoreTextView);

        String username = getIntent().getStringExtra("username");

        DBHelper dbHelper = new DBHelper(this);
        int score = dbHelper.getUserScore(username);

        scoreTextView.setText("User: " + username + "\nScore: " + score + "/10");
    }
}
